<?php $__env->startSection('title'); ?>
Ibadur-Rahman Institute
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section id="home" class="header-section section">
    <div class="left-header">
        <h1 >Ibadur-Rahman Institute</h1>
        <p>A dynamic organization devoted to developing an Islamic way of life</p>
    </div>
    <div class="header-image">
        <img src="<?php echo e(asset('frontend/img/quran-greens.png')); ?>" alt="Al qur'an" class="quran-img">
    </div>

</section>

<section  id="about">
  <div class="about-section section">

    <div class="about-details">
        <h2 class='text-center' > Welcome to IR Institute</h2>
        <p>‘Ibadur-Rahman Institute (IR Institute) aspires to be a center of excellence in learning, rendering religious services and propagating the Islamic faith. Our main interest is to advance the Islamic way of life in Societies and the dissemination of the prophetic messages through teaching, rendering services, counseling, mentoring, production of Islamic media contents, publication and policy recommendations.</p>


    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('frontend/js/index.js')); ?>"></script>
<?php if(session('status')): ?>
    <script>
        swal("Good job!", "<?php echo e(session('status')); ?>", "success");
    </script>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\irr\resources\views/welcome.blade.php ENDPATH**/ ?>